/**
 * In-game walkthrough — highlights real UI elements and guides
 * the player through their first round.
 *
 * Steps:
 *  1. Top-bar buttons
 *  2. Player hand
 *  3. Other players
 *  4. Queue area
 *  5. Party & Trash panels
 *  6. Leaderboard & Log
 *  7. Play a card (wait for real card play)
 *  8. Queue explained (after card played)
 *  9. Queue resolves → party/trash explained  (triggered externally)
 * 10. Goal
 */

import { t } from "../i18n.js";

const STORAGE_KEY = "walkthroughSeen";
const PAD = 10; // spotlight padding px

let _active    = false;
let _step      = 0;
let _onCardPlay = null;   // resolve fn — set when waiting for player card
let _onResolve  = null;   // resolve fn — set when waiting for queue resolve

/* ─────────────────────────────────────────
   Public API
───────────────────────────────────────── */

export function shouldShowWalkthrough() {
    return !localStorage.getItem(STORAGE_KEY);
}

export function markWalkthroughSeen() {
    localStorage.setItem(STORAGE_KEY, "true");
}

export function isWalkthroughActive() {
    return _active;
}

/**
 * Called by main.js after game starts (if first time).
 * Returns a promise that resolves when walkthrough is done/skipped.
 */
export function startWalkthrough() {
    return new Promise(resolve => {
        _active = true;
        _step   = 0;

        const overlay = document.getElementById("walkthroughOverlay");
        overlay.classList.remove("hidden");
        overlay.classList.add("active");

        _bindButtons(resolve);
        _showStep(0, resolve);
    });
}

/** Called by turnManager after the human plays a card */
export function notifyCardPlayed() {
    if (_onCardPlay) {
        const fn = _onCardPlay;
        _onCardPlay = null;
        fn();
    }
}

/** Called by queueManager after queue resolves (5 cards) */
export function notifyQueueResolved() {
    if (_onResolve) {
        const fn = _onResolve;
        _onResolve = null;
        fn();
    }
}

/* ─────────────────────────────────────────
   Step definitions
───────────────────────────────────────── */

function getSteps() {
    return [
        {
            // 1 — top bar buttons
            targetId:  "topBar",
            titleKey:  "wt1Title",
            textKey:   "wt1Text",
            arrowDir:  "up",
            boxPos:    "below",
        },
        {
            // 2 — player hand
            targetId:  "playerHand",
            titleKey:  "wt2Title",
            textKey:   "wt2Text",
            arrowDir:  "down",
            boxPos:    "above",
        },
        {
            // 3 — other players
            targetId:  "topPlayer",
            titleKey:  "wt3Title",
            textKey:   "wt3Text",
            arrowDir:  "up",
            boxPos:    "below",
            fallbackId: "leftPlayer",
        },
        {
            // 4 — queue
            targetId:  "queue",
            titleKey:  "wt4Title",
            textKey:   "wt4Text",
            arrowDir:  "down",
            boxPos:    "above",
        },
        {
            // 5 — party & trash
            targetId:  "partyCards",
            titleKey:  "wt5Title",
            textKey:   "wt5Text",
            arrowDir:  "left",
            boxPos:    "right",
            fallbackId: "trashCards",
        },
        {
            // 6 — leaderboard & log
            targetId:  "leaderboardRows",
            titleKey:  "wt6Title",
            textKey:   "wt6Text",
            arrowDir:  "left",
            boxPos:    "right",
            fallbackId: "logEntries",
        },
        {
            // 7 — play a card (interactive — wait for real play)
            targetId:  "playerHand",
            titleKey:  "wt7Title",
            textKey:   "wt7Text",
            arrowDir:  "down",
            boxPos:    "above",
            waitForCardPlay: true,
        },
        {
            // 8 — queue after card played
            targetId:  "queue",
            titleKey:  "wt8Title",
            textKey:   "wt8Text",
            arrowDir:  "down",
            boxPos:    "above",
        },
        {
            // 9 — queue resolve: party/trash (triggered when queue hits 5)
            targetId:  "queue",
            titleKey:  "wt9Title",
            textKey:   "wt9Text",
            arrowDir:  "down",
            boxPos:    "above",
            waitForResolve: true,   // this step waits until queue resolves
            showAfterResolve: true, // show AFTER resolve, not before
        },
        {
            // 10 — goal
            targetId:  null,        // center, no spotlight
            titleKey:  "wt10Title",
            textKey:   "wt10Text",
            arrowDir:  null,
            boxPos:    "center",
            isFinal:   true,
        },
    ];
}

/* ─────────────────────────────────────────
   Core render
───────────────────────────────────────── */

function _showStep(index, doneFn) {
    const steps = getSteps();
    if (index >= steps.length) { _finish(doneFn); return; }

    _step = index;
    const step = steps[index];

    // Update text
    document.getElementById("wtTitle").textContent    = t(step.titleKey);
    document.getElementById("wtStepLabel").textContent =
        t("wtStep").replace("{n}", index + 1).replace("{total}", steps.length);

    const rawText = t(step.textKey);
    document.getElementById("wtText").textContent = rawText;

    // Skip / Next button labels
    document.getElementById("wtSkipBtn").textContent = t("wtSkip");
    document.getElementById("wtNextBtn").textContent =
        step.isFinal ? t("wtDone") : t("wtNext");

    // Waiting for player interaction?
    const box = document.getElementById("walkthroughBox");
    if (step.waitForCardPlay) {
        box.classList.add("wt-waiting");
        // hand cards must be clickable
        _highlightElement("playerHand", true);
        // watch for the card play notification
        _onCardPlay = () => {
            _removeHighlight("playerHand");
            box.classList.remove("wt-waiting");
            _showStep(index + 1, doneFn);
        };
    } else if (step.waitForResolve) {
        // Just show this step's content after resolving
        _onResolve = () => {
            _showStep(index, doneFn);   // re-render same step without waitForResolve
        };
        // We don't show the step until queue resolves — hide overlay temporarily
        _hideOverlay();
        return;
    } else {
        box.classList.remove("wt-waiting");
        _onCardPlay = null;
    }

    // Show overlay
    _showOverlay();

    // Spotlight
    const targetEl = _getTarget(step);
    _positionSpotlight(targetEl);
    _positionBox(targetEl, step.boxPos, step.arrowDir);

    // Next button click
    const nextBtn = document.getElementById("wtNextBtn");
    nextBtn.onclick = () => {
        if (step.waitForCardPlay) return; // must play card
        if (step.showAfterResolve) {
            // queue already resolved, just advance
            _showStep(index + 1, doneFn);
            return;
        }
        _showStep(index + 1, doneFn);
    };
}

function _finish(doneFn) {
    _active = false;
    markWalkthroughSeen();
    _hideOverlay();
    if (doneFn) doneFn();
}

/* ─────────────────────────────────────────
   DOM helpers
───────────────────────────────────────── */

function _getTarget(step) {
    let el = step.targetId ? document.getElementById(step.targetId) : null;
    if (!el && step.fallbackId) el = document.getElementById(step.fallbackId);
    return el;
}

function _showOverlay() {
    const ov = document.getElementById("walkthroughOverlay");
    ov.classList.remove("hidden");
    ov.classList.add("active");
}

function _hideOverlay() {
    const ov = document.getElementById("walkthroughOverlay");
    ov.classList.add("hidden");
    ov.classList.remove("active");
}

function _positionSpotlight(el) {
    const spot = document.getElementById("walkthroughSpotlight");
    if (!el) {
        spot.style.display = "none";
        return;
    }
    spot.style.display = "block";

    const r = el.getBoundingClientRect();
    spot.style.left   = `${r.left   - PAD}px`;
    spot.style.top    = `${r.top    - PAD}px`;
    spot.style.width  = `${r.width  + PAD * 2}px`;
    spot.style.height = `${r.height + PAD * 2}px`;
}

function _positionBox(targetEl, boxPos, arrowDir) {
    const box   = document.getElementById("walkthroughBox");
    const arrow = document.getElementById("wtArrow");

    // Remove old arrow classes
    arrow.className = "wt-arrow";

    if (!targetEl || boxPos === "center") {
        // Center on screen
        box.style.top       = "50%";
        box.style.left      = "50%";
        box.style.transform = "translate(-50%,-50%)";
        box.style.bottom    = "auto";
        box.style.right     = "auto";
        return;
    }

    box.style.transform = "";
    const r       = targetEl.getBoundingClientRect();
    const bw      = 340;
    const margin  = 16;
    const vw      = window.innerWidth;
    const vh      = window.innerHeight;

    let top, left;

    switch(boxPos) {
        case "below":
            top  = r.bottom + PAD + margin;
            left = Math.max(margin, Math.min(r.left + r.width/2 - bw/2, vw - bw - margin));
            if (arrowDir) arrow.classList.add("arrow-up");
            break;
        case "above":
            top  = r.top - PAD - margin - 180;  // estimate box height
            left = Math.max(margin, Math.min(r.left + r.width/2 - bw/2, vw - bw - margin));
            if (top < margin) top = r.bottom + PAD + margin; // flip if no room
            if (arrowDir) arrow.classList.add("arrow-down");
            break;
        case "right":
            top  = Math.max(margin, r.top + r.height/2 - 90);
            left = r.right + PAD + margin;
            if (left + bw > vw) { left = r.left - PAD - margin - bw; arrow.classList.add("arrow-right"); }
            else if (arrowDir) arrow.classList.add("arrow-left");
            break;
        case "left":
            top  = Math.max(margin, r.top + r.height/2 - 90);
            left = r.left - PAD - margin - bw;
            if (left < margin) { left = r.right + PAD + margin; arrow.classList.add("arrow-left"); }
            else if (arrowDir) arrow.classList.add("arrow-right");
            break;
        default:
            top  = vh/2 - 90;
            left = vw/2 - bw/2;
    }

    // Clamp to viewport
    top  = Math.max(margin, Math.min(top,  vh - margin));
    left = Math.max(margin, Math.min(left, vw - bw - margin));

    box.style.top    = `${top}px`;
    box.style.left   = `${left}px`;
    box.style.bottom = "auto";
    box.style.right  = "auto";
}

function _highlightElement(id, on) {
    const el = document.getElementById(id);
    if (!el) return;
    if (on) el.classList.add("wt-highlight");
    else    el.classList.remove("wt-highlight");
}

function _removeHighlight(id) {
    _highlightElement(id, false);
}

/* ─────────────────────────────────────────
   Bind skip
───────────────────────────────────────── */

function _bindButtons(doneFn) {
    document.getElementById("wtSkipBtn").onclick = () => _finish(doneFn);
}
